
import React, { useState, useEffect } from 'react';
import { CheckCircle, Upload, Star, Trophy, FileText, Zap, Plus, Search, Clock, AlertCircle, Sparkles, Loader2, Target, ChevronRight, Info, WifiOff, AlertTriangle, XCircle, ShieldCheck, FolderOpen, ScanLine, Smartphone, Presentation, Lock, Wand2, Building, Trash2, MessageCircle } from 'lucide-react';
import { GoogleGenAI, Type } from '@google/genai';
import { createGeminiClient } from '../services/geminiClient';
import { motion } from 'motion/react';
import { collection, getDocs, query, where, getDoc, doc, deleteDoc } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../services/firebase';
import { handleGeminiError } from '../services/geminiError';
import StatCard from '../components/StatCard';
import ComplianceTracker from '../components/ComplianceTracker';
import GlassAvatar from '../components/GlassAvatar';
import { MOCK_ACHIEVEMENTS } from '../constants';
import { loadOpportunities } from '../services/opportunitiesStore';
import { User, Application, ApplicationStatus, FundingType, AppDocument, FundingOpportunityDb, ReadinessInfo } from '../types';
import FormDigitizer from '../components/FormDigitizer';
import PresentationDesigner from '../components/PresentationDesigner';
import ProposalStudio from '../components/proposal/ProposalStudio';
import AILogoGenerator from '../components/AILogoGenerator';
import AdvertGenerator from '../components/AdvertGenerator';
import FundingNeedsTracker from '../components/FundingNeedsTracker';
import { ApplicationTracker } from '../components/ApplicationTracker';
import DocumentsVault from '../components/DocumentsVault';
import { WhatsAppIngestion } from '../components/WhatsAppIngestion';
import FundingHeatmap from '../components/FundingHeatmap';
import AIFundingInsights from '../components/AIFundingInsights';
import FundingCountdown from '../components/FundingCountdown';
import FundingAnalyticsSection from '../components/FundingAnalyticsSection';
import ApplicationFunnelChart from '../components/ApplicationFunnelChart';
import AlertPreferences from '../components/AlertPreferences';
import { compileUserDeadlines, getCutoffCountdown, parseCutoffDate } from '../services/fundingDeadlineService';

const XPCoin: React.FC<{ styleClass: string; index: number }> = ({ styleClass, index }) => (
  <motion.div
    initial={{ scale: 0, rotateY: 720, y: -50, x: -50, opacity: 0 }}
    animate={{ scale: 1, rotateY: 0, y: 0, x: 0, opacity: 1 }}
    transition={{ 
      type: 'spring', 
      damping: 12, 
      mass: 0.8, 
      stiffness: 100,
      delay: index * 0.1
    }}
    className={`w-5 h-5 sm:w-6 sm:h-6 rounded-full bg-gradient-to-br ${styleClass} border flex items-center justify-center shadow-lg relative`}
  >
    <div className="absolute inset-0 rounded-full border-t-2 border-white/40" />
    <span className="text-[6px] sm:text-[8px] font-black text-white drop-shadow-md">XP</span>
  </motion.div>
);

interface DashboardProps {
  onCompleteProfile: () => void;
  onBrowseFunding: (oppId?: string, resume?: boolean, fallback?: any) => void;
  onAvatarUpdate?: (url: string) => void;
  onUpgrade: () => void;
  user: User | null;
  activeSection?: 'overview' | 'applications' | 'opportunities' | 'needs' | 'tools' | 'documents';
  onNavigateToSection?: (section: 'overview' | 'applications' | 'opportunities' | 'needs' | 'tools' | 'documents') => void;
}

interface AIMatch {
  id: string;
  matchReason: string;
  score: number;
}

// Add a small helper component for Application logos to handle fallbacks
const ApplicationLogo = ({ app }: { app: Application }) => {
  const [fallbackStage, setFallbackStage] = useState(0);

  const domain = React.useMemo(() => {
    try {
      if (app.logoUrl && app.logoUrl.includes('google.com/s2/favicons?domain=')) {
        return app.logoUrl.split('domain=')[1].split('&')[0];
      }
      if (app.logoUrl && app.logoUrl.includes('clearbit.com/')) {
        return app.logoUrl.split('clearbit.com/')[1].split('?')[0];
      }
      return null;
    } catch {
      return null;
    }
  }, [app.logoUrl]);

  const currentUrl = React.useMemo(() => {
    if (fallbackStage === 0 && app.logoUrl) {
      return app.logoUrl;
    }
    if (fallbackStage <= 1 && domain) {
      return `https://www.google.com/s2/favicons?domain=${domain}&sz=128`;
    }
    return null;
  }, [app.logoUrl, domain, fallbackStage]);

  if (currentUrl) {
    return (
      <img 
        src={currentUrl} 
        alt={app.provider} 
        className="w-full h-full object-contain p-1.5 bg-white" 
        onError={() => setFallbackStage(prev => prev + 1)}
        referrerPolicy="no-referrer"
      />
    );
  }

  return (
    <>
      {app.type === FundingType.GRANT ? '💰' : 
       app.type === FundingType.EQUITY ? '📈' : 
       app.type === FundingType.LOAN ? '🏦' : '🏆'}
    </>
  );
};

const Dashboard: React.FC<DashboardProps> = ({ onCompleteProfile, onBrowseFunding, onAvatarUpdate, onUpgrade, user, activeSection = 'overview', onNavigateToSection }) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'applications' | 'opportunities' | 'needs' | 'tools'>(activeSection);
  
  useEffect(() => {
    setActiveTab(activeSection);
  }, [activeSection]);

  const [applications, setApplications] = useState<Application[]>([]);
  const [docCount, setDocCount] = useState(0);
  const [isOffline, setIsOffline] = useState(!navigator.onLine);
  
  const [selectedApplicationForTracker, setSelectedApplicationForTracker] = useState<Application | null>(null);
  
  const [allOpportunities, setAllOpportunities] = useState<FundingOpportunityDb[]>([]);
  const [aiMatches, setAiMatches] = useState<AIMatch[]>([]);
  const [isLoadingAI, setIsLoadingAI] = useState(false);
  const [hasProfile, setHasProfile] = useState(false);
  const [businessInfo, setBusinessInfo] = useState<any>({});
  const [ownerInfo, setOwnerInfo] = useState<any>({});
  const [readiness, setReadiness] = useState<ReadinessInfo | null>(null);
  const [isLoadingReadiness, setIsLoadingReadiness] = useState(false);
  
  const [showFormDigitizer, setShowFormDigitizer] = useState(false);
  const [showPresentationDesigner, setShowPresentationDesigner] = useState(false);
  const [showProposalStudio, setShowProposalStudio] = useState(false);
  const [showLogoGenerator, setShowLogoGenerator] = useState(false);
  const [showAdvertGenerator, setShowAdvertGenerator] = useState(false);
  const [showWhatsAppIngestion, setShowWhatsAppIngestion] = useState(false);
  // UI hint only: the server decides who really is an admin (ADMIN_EMAILS on the server).
  const intakeAdminEmails = (
    ((import.meta as unknown as { env?: Record<string, string | undefined> }).env?.VITE_ADMIN_EMAILS) ?? ''
  )
    .split(',')
    .map((e) => e.trim().toLowerCase())
    .filter(Boolean);
  const isIntakeAdmin = intakeAdminEmails.includes((user?.email ?? '').toLowerCase());
  const [initialAdvertPrompt, setInitialAdvertPrompt] = useState('');
  
  const [prevTotalCoins, setPrevTotalCoins] = useState(-1);

  let points = 0;
  if (hasProfile) points += 100;
  points += docCount * 20;
  applications.forEach(app => {
    if (app.status === ApplicationStatus.DRAFT) points += 30;
    else if (app.status === ApplicationStatus.SUBMITTED) points += 80;
    else if (app.status === ApplicationStatus.UNDER_REVIEW) points += 100;
    else if (app.status === ApplicationStatus.APPROVED) points += 300;
    else if (app.status === ApplicationStatus.REJECTED) points += 50;
  });

  useEffect(() => {
    const currentTotalCoins = Math.floor(points / 20);
    if (prevTotalCoins !== -1 && currentTotalCoins > prevTotalCoins) {
    }
    if (currentTotalCoins !== prevTotalCoins) {
      setPrevTotalCoins(currentTotalCoins);
    }
  }, [points, prevTotalCoins]);

  // Real Data Fetching
  useEffect(() => {
    const handleOpenAiTool = (event: any) => {
      const { tool, prompt } = event.detail;
      
      if (tool !== 'digitizer' && user?.subscriptionPlan === 'free') {
        onUpgrade();
        return;
      }

      if (tool === 'logo') {
        setShowLogoGenerator(true);
      } else if (tool === 'advert') {
        if (prompt) setInitialAdvertPrompt(prompt);
        setShowAdvertGenerator(true);
      } else if (tool === 'digitizer') {
        setShowFormDigitizer(true);
      } else if (tool === 'presentation') {
        setShowPresentationDesigner(true);
      } else if (tool === 'proposal') {
        setShowProposalStudio(true);
      }
    };
    window.addEventListener('open_ai_tool', handleOpenAiTool);
    return () => window.removeEventListener('open_ai_tool', handleOpenAiTool);
  }, [user, onUpgrade]);

  useEffect(() => {
    const handleUpdateTab = (event: any) => {
      if (['overview', 'applications', 'opportunities', 'needs', 'tools'].includes(event.detail.tab)) {
        if (onNavigateToSection) {
          onNavigateToSection(event.detail.tab);
        } else {
          setActiveTab(event.detail.tab);
        }
      }
    };
    window.addEventListener('update_dashboard_tab', handleUpdateTab);
    return () => window.removeEventListener('update_dashboard_tab', handleUpdateTab);
  }, [onNavigateToSection]);

  useEffect(() => {
    const handleOpenOppFromNotif = (event: any) => {
      if (event.detail?.opportunityId) {
        onBrowseFunding(event.detail.opportunityId);
      }
    };
    window.addEventListener('open_opportunity_from_notification', handleOpenOppFromNotif);
    return () => window.removeEventListener('open_opportunity_from_notification', handleOpenOppFromNotif);
  }, [onBrowseFunding]);

  // Load published opportunities (Firestore + built-in fallback) on mount
  // and refresh them whenever the admin publishes/rejects from the intake screen.
  useEffect(() => {
    let cancelled = false;
    loadOpportunities().then((ops) => {
      if (!cancelled) setAllOpportunities(ops);
    });
    const handleInvalidate = () => loadOpportunities(true).then((ops) => {
      if (!cancelled) setAllOpportunities(ops);
    });
    window.addEventListener('stacfund_opportunities_invalidated', handleInvalidate);
    return () => {
      cancelled = true;
      window.removeEventListener('stacfund_opportunities_invalidated', handleInvalidate);
    };
  }, []);

  useEffect(() => {
    const fetchDashboardData = async () => {
        if (!user) return;

        try {
            // 1. Fetch Applications from Subcollection
            const appsRef = collection(db, 'users', user.id, 'applications');
            const appSnapshot = await getDocs(appsRef);
            const fetchedApps = appSnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Application));
            setApplications(fetchedApps);

            // 2. Fetch Document Count
            const docsRef = collection(db, 'users', user.id, 'documents');
            const docSnapshot = await getDocs(docsRef);
            setDocCount(docSnapshot.size);

            // 3. Fetch Profile for Readiness
            const userDocRef = doc(db, 'users', user.id);
            const userDoc = await getDoc(userDocRef);
            if (userDoc.exists()) {
                const data = userDoc.data();
                if (data.profile) {
                    setHasProfile(true);
                    setBusinessInfo(data.profile);
                    setOwnerInfo(data.ownerInfo || {});
                    const combinedProfile = {
                      ...data.profile,
                      ownerInfo: data.ownerInfo || {}
                    };
                    calculateReadiness(JSON.stringify(combinedProfile), docSnapshot.size);
                }
            }
        } catch (e) {
            handleFirestoreError(e, OperationType.GET, `users/${user.id}`);
        }
    };

    fetchDashboardData();
  }, [user]);

  // Network Status listener
  useEffect(() => {
    const handleStatusChange = () => setIsOffline(!navigator.onLine);
    window.addEventListener('online', handleStatusChange);
    window.addEventListener('offline', handleStatusChange);
    return () => {
      window.removeEventListener('online', handleStatusChange);
      window.removeEventListener('offline', handleStatusChange);
    };
  }, []);

  const calculateReadiness = async (profileStr: string, docs: number) => {
    if (isOffline) return;
    setIsLoadingReadiness(true);
    try {
      const ai = await createGeminiClient();
      const prompt = `Analyze this business profile and document count (${docs} docs uploaded). 
      Profile: ${profileStr}. 
      Return a JSON object with "score" (0-100) representing funding readiness and "tips" (array of 3 short strings) to improve it.`;
      
      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: prompt,
        config: { 
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              score: { type: Type.NUMBER },
              tips: { type: Type.ARRAY, items: { type: Type.STRING } }
            },
            required: ['score', 'tips']
          }
        }
      });
      let text = response.text || '{"score": 0, "tips": []}';
      text = text.replace(/```json\n?/g, '').replace(/```\n?/g, '').trim();
      const data = JSON.parse(text);
      setReadiness(data);
    } catch (e) {
      
      handleGeminiError(e);
    } finally {
      setIsLoadingReadiness(false);
    }
  };

  const runAIMatching = async () => {
    if (!user || !hasProfile || isOffline) return;
    
    setIsLoadingAI(true);
    try {
      // Re-fetch profile to ensure freshness
      const userDoc = await getDoc(doc(db, 'users', user.id));
      const profileData = userDoc.exists() ? JSON.stringify({
        ...userDoc.data().profile,
        ownerInfo: userDoc.data().ownerInfo || {}
      }) : '';

      const ai = await createGeminiClient();
      
      const prompt = `
        You are a business funding expert. Analyze:
        USER PROFILE: ${profileData}
        FUNDING: ${JSON.stringify(allOpportunities)}
        Return JSON array of objects with "id", "matchReason", "score".
      `;

      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: prompt,
        config: { 
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                id: { type: Type.STRING },
                matchReason: { type: Type.STRING },
                score: { type: Type.NUMBER }
              },
              required: ['id', 'matchReason', 'score']
            }
          }
        }
      });

      let text = response.text || '[]';
      text = text.replace(/```json\n?/g, '').replace(/```\n?/g, '').trim();
      const matches = JSON.parse(text);
      setAiMatches(matches);
    } catch (error) {
      
      handleGeminiError(error);
    } finally {
      setIsLoadingAI(false);
    }
  };

  useEffect(() => {
    if (activeTab === 'opportunities' && aiMatches.length === 0 && hasProfile) {
      runAIMatching();
    }
  }, [activeTab]);

  const handleToolClick = (tool: 'digitizer' | 'presentation' | 'proposal' | 'logo' | 'register' | 'whatsapp') => {
    if (tool !== 'digitizer' && user?.subscriptionPlan === 'free') {
      onUpgrade();
      return;
    }
    
    if (tool === 'digitizer') setShowFormDigitizer(true);
    if (tool === 'presentation') setShowPresentationDesigner(true);
    if (tool === 'proposal') setShowProposalStudio(true);
    if (tool === 'logo') setShowLogoGenerator(true);
    if (tool === 'whatsapp') setShowWhatsAppIngestion(true);
  };

  const clearAllApplications = async () => {
    if (!user) return;
    
    try {
      const appsRef = collection(db, 'users', user.id, 'applications');
      const appSnapshot = await getDocs(appsRef);
      const deletePromises = appSnapshot.docs.map(document => deleteDoc(doc(db, 'users', user.id, 'applications', document.id)));
      await Promise.all(deletePromises);
      setApplications([]);
    } catch (e) {
      console.error("Failed to clear applications:", e);
    }
  };

  const getStatusStyle = (status: ApplicationStatus) => {
    switch (status) {
      case ApplicationStatus.DRAFT: return 'bg-purple-500/20 text-purple-400 border-purple-500/30';
      case ApplicationStatus.SUBMITTED: return 'bg-blue-500/20 text-blue-400 border-blue-500/30';
      case ApplicationStatus.UNDER_REVIEW: return 'bg-amber-500/20 text-amber-400 border-amber-500/30';
      case ApplicationStatus.APPROVED: return 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30';
      case ApplicationStatus.REJECTED: return 'bg-red-500/20 text-red-400 border-red-500/30';
      default: return 'bg-gray-500/20 text-gray-400 border-gray-500/30';
    }
  };

  const getProgress = (status: ApplicationStatus) => {
    switch (status) {
      case ApplicationStatus.DRAFT: return 25;
      case ApplicationStatus.SUBMITTED: return 50;
      case ApplicationStatus.UNDER_REVIEW: return 75;
      case ApplicationStatus.APPROVED: return 100;
      case ApplicationStatus.REJECTED: return 100;
      default: return 0;
    }
  };

  const getProgressBarColor = (status: ApplicationStatus) => {
    switch (status) {
      case ApplicationStatus.DRAFT: return 'bg-purple-500';
      case ApplicationStatus.SUBMITTED: return 'bg-blue-500';
      case ApplicationStatus.UNDER_REVIEW: return 'bg-amber-500';
      case ApplicationStatus.APPROVED: return 'bg-emerald-500';
      case ApplicationStatus.REJECTED: return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  const isPaid = user?.subscriptionPlan !== 'free';

  const complianceItems = [
    { id: '1', name: 'Certified ID Copy', dueDate: '2026-12-31', isComplete: docCount > 0, notes: 'Must be certified within 3 months.' },
    { id: '2', name: 'Proof of Address', dueDate: '2026-06-30', isComplete: docCount > 1, notes: 'Bank statement or lease agreement.' },
    { id: '3', name: 'B-BBEE Sworn Affidavit', dueDate: '2027-02-28', isComplete: docCount > 2, notes: 'Signed by Commissioner of Oaths.' },
    { id: '4', name: 'SARS Tax Clearance', dueDate: '2026-10-31', isComplete: docCount > 3, notes: 'Active PIN required.' }
  ];

  return (
    <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8 lg:py-10 relative min-w-0">
      {showFormDigitizer && (
        <FormDigitizer user={user} onClose={() => setShowFormDigitizer(false)} />
      )}
      {showPresentationDesigner && (
        <PresentationDesigner user={user} onClose={() => setShowPresentationDesigner(false)} />
      )}
      {showProposalStudio && (
        <ProposalStudio user={user} onClose={() => setShowProposalStudio(false)} />
      )}
      {showLogoGenerator && (
        <AILogoGenerator user={user} onClose={() => setShowLogoGenerator(false)} />
      )}
      {showAdvertGenerator && (
        <AdvertGenerator user={user} onClose={() => setShowAdvertGenerator(false)} initialPrompt={initialAdvertPrompt} />
      )}
      {showWhatsAppIngestion && (
        <WhatsAppIngestion user={user} onClose={() => setShowWhatsAppIngestion(false)} />
      )}

      {isOffline && (
        <div className="mb-8 p-4 bg-amber-500/10 border border-amber-500/20 rounded-2xl flex items-center justify-between animate-in slide-in-from-top duration-500">
           <div className="flex items-center gap-3 text-amber-400">
             <WifiOff size={20} />
             <span className="text-sm font-bold uppercase tracking-wider">You are currently offline</span>
           </div>
           <p className="text-[10px] text-amber-400/60 font-black">LOCAL-FIRST MODE ACTIVE</p>
        </div>
      )}

      <div className="flex flex-col lg:flex-row gap-6 xl:gap-8 items-start w-full min-w-0">
        <div className="flex-1 min-w-0 w-full space-y-6 lg:space-y-8">
          {/* Welcome Card & Level Tracker */}
          <div className="glass-panel rounded-3xl p-6 sm:p-8 relative overflow-hidden group flex flex-col gap-6 w-full min-w-0">
            <div className="absolute top-0 right-0 w-32 h-32 bg-purple-600/10 blur-[60px] group-hover:bg-purple-600/20 transition-all pointer-events-none"></div>
            
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-6 relative z-10 w-full min-w-0">
              <div className="min-w-0 flex-1">
                <h2 className="text-2xl sm:text-3xl font-black mb-1 truncate">Welcome back{user ? `, ${user.email.split('@')[0]}` : ''}! 👋</h2>
                <p className="text-gray-400 font-medium truncate">{user?.businessName || 'New Entrepreneur'}</p>
              </div>
              <GlassAvatar 
                initialLogoUrl={user?.logoUrl} 
                businessName={user?.businessName || 'User'} 
                onUpdate={onAvatarUpdate}
              />
            </div>

            {/* Founder Level Tracker */}
            {(() => {
              const getFounderLevel = (p: number) => {
                if (p >= 1000) return { name: 'Galactic Titan', min: 1000, max: 2000, icon: '🌟', coinStyle: 'from-cyan-300 to-cyan-500 border-cyan-100 shadow-[0_0_8px_#22d3ee]' };
                if (p >= 500) return { name: 'Stellar Commander', min: 500, max: 1000, icon: '🚀', coinStyle: 'from-blue-200 to-purple-400 border-white shadow-[0_0_8px_#d8b4fe]' };
                if (p >= 250) return { name: 'Lunar Explorer', min: 250, max: 500, icon: '🛰️', coinStyle: 'from-yellow-300 to-yellow-500 border-yellow-200 shadow-[0_0_8px_#facc15]' };
                if (p >= 100) return { name: 'Orbital Pioneer', min: 100, max: 250, icon: '🛸', coinStyle: 'from-gray-300 to-gray-400 border-gray-100 shadow-[0_0_8px_#9ca3af]' };
                return { name: 'Space Cadet', min: 0, max: 100, icon: '👨‍🚀', coinStyle: 'from-amber-600 to-amber-700 border-amber-400 shadow-[0_0_8px_#d97706]' };
              };

              const level = getFounderLevel(points);
              const progressPercentage = Math.min(100, Math.max(0, ((points - level.min) / (level.max - level.min)) * 100));
              
              const currentLevelPoints = points - level.min;
              const coinCount = Math.floor(currentLevelPoints / 20);
              const coinsToDisplay = Array.from({ length: coinCount }).map((_, i) => i);

              return (
                <div className="mt-2 pt-6 border-t border-white/5 relative z-10 w-full min-w-0">
                  <div className="flex justify-between items-end mb-3 gap-2 flex-wrap sm:flex-nowrap">
                    <div className="min-w-0">
                      <p className="text-xs text-gray-500 uppercase tracking-widest font-bold mb-1">Founder Level</p>
                      <div className="flex items-center gap-2">
                        <span className="text-2xl shrink-0">{level.icon}</span>
                        <h3 className="text-xl font-black bg-clip-text text-transparent bg-gradient-to-r from-purple-400 to-blue-400 truncate">
                          {level.name}
                        </h3>
                      </div>
                    </div>
                    <div className="text-right flex flex-col items-end shrink-0 ml-auto">
                      <div className="flex items-center gap-2 sm:gap-3 mb-1">
                        <div className="flex -space-x-2 max-w-[140px] overflow-hidden">
                          {coinsToDisplay.slice(0, 8).map(i => (
                            <XPCoin key={i} index={i} styleClass={level.coinStyle} />
                          ))}
                        </div>
                        <p className="text-sm font-bold whitespace-nowrap">{points} <span className="text-gray-500 font-normal">XP</span></p>
                      </div>
                      <p className="text-[10px] text-gray-500 font-bold uppercase tracking-widest whitespace-nowrap">{level.max - points} XP to next rank</p>
                    </div>
                  </div>
                  <div className="h-2 w-full bg-gray-800 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-gradient-to-r from-purple-500 to-blue-500 transition-all duration-1000 ease-out rounded-full"
                      style={{ width: `${progressPercentage}%` }}
                    />
                  </div>
                </div>
              );
            })()}
          </div>

          {/* Quick Stats Grid */}
          <div className="grid grid-cols-3 gap-3 md:gap-4 xl:gap-6 w-full min-w-0">
            <StatCard label="Applications" value={applications.length} icon={<FileText size={24} />} />
            <StatCard label="Submitted" value={applications.filter(a => a.status === ApplicationStatus.SUBMITTED).length} icon={<CheckCircle size={24} />} colorClass="text-emerald-400" />
            <StatCard label="Documents" value={docCount} icon={<Upload size={24} />} colorClass="text-blue-400" />
          </div>

          <div className="space-y-6 w-full min-w-0">
            {activeTab === 'overview' && (
              <>
                <div className="grid grid-cols-2 gap-3 md:gap-4 w-full min-w-0">
                  <button onClick={onCompleteProfile} className="glass-panel p-4 md:p-6 rounded-2xl flex flex-col md:flex-row items-center md:items-start text-center md:text-left gap-3 md:gap-4 hover:bg-purple-600/10 border-t-4 md:border-t-0 border-purple-500 md:border-l-4 md:border-l-purple-500 transition-all group min-w-0">
                    <div className="w-10 h-10 md:w-12 md:h-12 rounded-xl bg-purple-500/20 flex items-center justify-center text-purple-400 group-hover:scale-110 transition-transform shrink-0"><Plus size={20} className="md:w-6 md:h-6" /></div>
                    <div className="min-w-0"><h4 className="font-bold text-sm md:text-base leading-tight md:leading-normal truncate">Complete Profile</h4><p className="text-[10px] md:text-xs text-purple-400/80 font-bold tracking-wider mt-1 md:mt-0 truncate">Unlock Auto-Fill</p></div>
                  </button>
                  <button onClick={() => onBrowseFunding()} className="glass-panel p-4 md:p-6 rounded-2xl flex flex-col md:flex-row items-center md:items-start text-center md:text-left gap-3 md:gap-4 hover:bg-emerald-600/10 border-t-4 md:border-t-0 border-emerald-500 md:border-l-4 md:border-l-emerald-500 transition-all group min-w-0">
                    <div className="w-10 h-10 md:w-12 md:h-12 rounded-xl bg-emerald-500/20 flex items-center justify-center text-emerald-400 group-hover:scale-110 transition-transform shrink-0"><Search size={20} className="md:w-6 md:h-6" /></div>
                    <div className="min-w-0"><h4 className="font-bold text-sm md:text-base leading-tight md:leading-normal truncate">Browse Funding</h4><p className="text-[10px] md:text-xs text-emerald-400/80 font-bold tracking-wider mt-1 md:mt-0 truncate">Find perfect match</p></div>
                  </button>
                </div>

                {/* Funding Analytics & Application Stage Funnel (Recharts) */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 w-full min-w-0">
                  <FundingAnalyticsSection
                    user={user}
                    applications={applications}
                    opportunities={allOpportunities}
                    onBrowseFunding={() => onBrowseFunding()}
                    onOpenNeedsTracker={() => {
                      if (onNavigateToSection) onNavigateToSection('needs');
                      else setActiveTab('needs');
                    }}
                  />
                  <ApplicationFunnelChart
                    applications={applications}
                    onBrowseFunding={() => onBrowseFunding()}
                    onNavigateToApplications={() => {
                      if (onNavigateToSection) onNavigateToSection('applications');
                      else setActiveTab('applications');
                    }}
                  />
                </div>

                {/* Funding Countdown & Cutoff Deadlines */}
                <FundingCountdown
                  user={user}
                  applications={applications}
                  opportunities={allOpportunities}
                  onOpenApplication={(oppId, isDraft, fallback) => {
                    onBrowseFunding(oppId, isDraft, fallback);
                  }}
                  onNavigateToApplications={() => {
                    if (onNavigateToSection) onNavigateToSection('applications');
                    else setActiveTab('applications');
                  }}
                />

                {/* AI Funding Insights: Industry Trends, Grant Inflows & Allocator Intelligence */}
                <AIFundingInsights
                  user={user}
                  businessInfo={{
                    ...businessInfo,
                    name: businessInfo?.name || user?.businessName
                  }}
                  onExploreIndustry={(_industry) => onBrowseFunding()}
                />

                <FundingHeatmap onSelectOpportunity={(oppId) => onBrowseFunding(oppId)} />

                <div className="space-y-4 w-full min-w-0">
                  <div className="flex justify-between items-center">
                    <h3 className="text-lg font-bold">Recent Applications</h3>
                    <button onClick={() => onNavigateToSection ? onNavigateToSection('applications') : setActiveTab('applications')} className="text-xs font-bold text-purple-400 hover:text-purple-300 uppercase tracking-wider">View All</button>
                  </div>
                  {applications.length > 0 ? (
                    applications.slice(0, 3).map(app => (
                      <div 
                        key={app.id} 
                        className={`glass-panel p-4 sm:p-5 rounded-2xl flex items-center justify-between group hover:border-white/20 transition-all cursor-pointer w-full min-w-0 gap-3`}
                        onClick={() => {
                          if (app.status === ApplicationStatus.DRAFT) {
                            onBrowseFunding(app.opportunityId || app.id, true, {
                              title: app.opportunityTitle || 'Unknown Opportunity',
                              provider: app.provider || 'Unknown Provider',
                              type: app.type || FundingType.GRANT
                            });
                          } else {
                            setSelectedApplicationForTracker(app);
                          }
                        }}
                      >
                        <div className="flex items-center gap-3 sm:gap-4 min-w-0 flex-1">
                          <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-xl bg-[#111] overflow-hidden flex items-center justify-center text-xl border border-white/10 shrink-0">
                            <ApplicationLogo app={app} />
                          </div>
                          <div className="min-w-0 flex-1">
                            <h4 className="font-bold group-hover:text-purple-400 transition-colors truncate">{app.opportunityTitle}</h4>
                            <p className="text-xs text-gray-500 truncate">{app.provider} • {app.date}</p>
                          </div>
                        </div>
                        <div className={`flex items-center gap-1.5 sm:gap-2 px-2.5 sm:px-3 py-1 rounded-full text-[10px] font-black border uppercase tracking-wider shrink-0 ${getStatusStyle(app.status)}`}>
                          {app.status === ApplicationStatus.DRAFT ? 'IN PROGRESS' : app.status.replace('_', ' ')}
                          {app.submissionMethod === 'DIRECT_API' && <Zap size={10} className="text-amber-400 fill-amber-400" title="Direct Connect Fast-Track" />}
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="glass-panel p-16 rounded-3xl text-center opacity-50">
                      <p className="text-gray-500 font-bold">No applications yet. Start exploring funding options.</p>
                    </div>
                  )}
                </div>
              </>
            )}

            {activeTab === 'applications' && (
              <div className="space-y-6 animate-in fade-in slide-in-from-bottom-2 duration-300">
                <div className="flex justify-between items-center">
                  <h3 className="text-2xl font-black">My Applications</h3>
                  <div className="flex items-center gap-3">
                    {applications.length > 0 && (
                      <button 
                        onClick={clearAllApplications}
                        className="text-xs font-bold text-red-500 hover:bg-red-500/10 px-3 py-1.5 rounded-lg transition-all flex items-center gap-1 uppercase tracking-widest border border-red-500/0 hover:border-red-500/20"
                        title="Clear all applications to start fresh"
                      >
                        <Trash2 size={14} /> Clear Slate
                      </button>
                    )}
                    <div className="text-xs font-bold text-gray-500 uppercase tracking-widest bg-white/5 px-3 py-1 rounded-full">
                      {applications.length} Total
                    </div>
                  </div>
                </div>
                
                <div className="grid grid-cols-1 gap-4">
                  {applications.length > 0 ? (
                    applications.map(app => {
                      const progress = getProgress(app.status);
                      const colorClass = getProgressBarColor(app.status);
                      
                      return (
                        <div 
                          key={app.id} 
                          className={`glass-panel p-6 rounded-3xl group hover:border-white/20 transition-all relative overflow-hidden cursor-pointer`}
                          onClick={() => {
                            if (app.status === ApplicationStatus.DRAFT) {
                              onBrowseFunding(app.opportunityId || app.id, true, {
                                title: app.opportunityTitle || 'Unknown Opportunity',
                                provider: app.provider || 'Unknown Provider',
                                type: app.type || FundingType.GRANT
                              });
                            } else {
                              setSelectedApplicationForTracker(app);
                            }
                          }}
                        >
                          {app.status === ApplicationStatus.REJECTED && (
                            <div className="absolute top-0 right-0 p-2 bg-red-500/20 rounded-bl-xl text-red-400 border-l border-b border-red-500/20">
                              <XCircle size={14} />
                            </div>
                          )}
                          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 sm:gap-6 min-w-0 w-full">
                            <div className="flex items-center gap-3 sm:gap-4 min-w-0 flex-1">
                              <div className="w-12 sm:w-14 h-12 sm:h-14 rounded-2xl bg-[#111] overflow-hidden flex items-center justify-center text-xl sm:text-2xl shadow-inner group-hover:scale-110 transition-transform border border-white/10 shrink-0">
                                <ApplicationLogo app={app} />
                              </div>
                              <div className="min-w-0 flex-1">
                                <h4 className="text-base sm:text-lg font-bold group-hover:text-purple-400 transition-colors truncate">{app.opportunityTitle}</h4>
                                <div className="flex items-center gap-2 flex-wrap">
                                  <p className="text-xs text-gray-500 font-medium truncate">{app.provider} • Applied on {app.date}</p>
                                  {(() => {
                                    const matchingOpp = allOpportunities.find(o => o.opportunity_id === app.opportunityId);
                                    const cutoffDate = parseCutoffDate(app.deadline || matchingOpp?.closing_date);
                                    const countdown = cutoffDate ? getCutoffCountdown(cutoffDate) : null;
                                    if (!countdown || countdown.passed) return null;
                                    return (
                                      <span className={`inline-flex items-center gap-1 text-[9px] font-black uppercase tracking-wider px-2 py-0.5 rounded-full border ${
                                        countdown.urgency === 'critical' 
                                          ? 'bg-rose-500/20 text-rose-300 border-rose-500/40 animate-pulse' 
                                          : countdown.urgency === 'imminent'
                                            ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                                            : 'bg-cyan-500/10 text-cyan-300 border-cyan-500/20'
                                      }`}>
                                        <Clock size={10} />
                                        {countdown.urgency === 'critical' && <Zap size={10} className="fill-rose-400 text-rose-400" />}
                                        Cutoff: {countdown.days > 0 ? `${countdown.days}d ${countdown.hours}h` : `${countdown.hours}h ${countdown.minutes}m`}
                                      </span>
                                    );
                                  })()}
                                </div>
                              </div>
                            </div>

                            <div className="flex-1 max-w-md w-full">
                              <div className="flex justify-between items-end mb-2">
                                <span className={`text-[10px] font-black uppercase tracking-widest ${app.status === ApplicationStatus.REJECTED ? 'text-red-400' : 'text-gray-500'}`}>
                                  {app.status === ApplicationStatus.REJECTED ? 'Application Terminated' : 'Application Progress'}
                                  <span className="ml-2 font-bold text-gray-400 normal-case">{progress}%</span>
                                </span>
                                <span className={`text-xs font-black px-2 py-0.5 rounded-md ${app.status === ApplicationStatus.REJECTED ? 'bg-red-500/10 text-red-400' : 'text-white'}`}>
                                  {app.status === ApplicationStatus.DRAFT ? 'IN PROGRESS' : app.status.replace('_', ' ')}
                                  {app.submissionMethod === 'DIRECT_API' && (
                                    <span className="ml-2 text-amber-400 inline-flex items-center gap-1 bg-amber-400/10 px-1.5 py-0.5 rounded text-[8px]">
                                      <Zap size={10} className="fill-amber-400" /> FAST-TRACK
                                    </span>
                                  )}
                                </span>
                              </div>
                              <div className="h-2 w-full bg-white/5 rounded-full overflow-hidden">
                                <div 
                                  className={`h-full transition-all duration-1000 ease-out rounded-full ${colorClass} ${app.status !== ApplicationStatus.REJECTED ? 'shadow-[0_0_10px_rgba(255,255,255,0.1)]' : ''}`}
                                  style={{ width: `${progress}%` }}
                                ></div>
                              </div>
                            </div>
                            
                            <div className="flex items-center gap-3">
                               {app.status === ApplicationStatus.REJECTED ? (
                                 <div className="p-2.5 rounded-xl bg-red-500/10 text-red-400 border border-red-500/20" title="Application Rejected">
                                   <AlertCircle size={20} />
                                 </div>
                               ) : app.status === ApplicationStatus.APPROVED ? (
                                 <div className="p-2.5 rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/20" title="Funding Approved!">
                                   <Trophy size={20} />
                                 </div>
                               ) : null}
                               <button className="p-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-gray-400 hover:text-white transition-all">
                                 <ChevronRight size={20} />
                               </button>
                            </div>
                          </div>
                        </div>
                      );
                    })
                  ) : (
                    <div className="glass-panel p-20 rounded-3xl text-center opacity-50 flex flex-col items-center gap-4">
                      <FileText size={48} className="text-gray-600" />
                      <p className="text-gray-500 font-bold">You haven't applied for any funding yet.</p>
                      <button onClick={() => onBrowseFunding()} className="text-purple-400 hover:underline font-black uppercase text-xs tracking-widest">Browse Opportunities</button>
                    </div>
                  )}
                </div>
              </div>
            )}


            {activeTab === 'documents' && (
              <DocumentsVault user={user} />
            )}

            {activeTab === 'needs' && (
              <div className="animate-in fade-in slide-in-from-bottom-2 duration-300">
                <FundingNeedsTracker 
                   user={user} 
                   onUpgrade={onUpgrade} 
                   businessInfo={{...businessInfo, name: businessInfo.name || user?.businessName}} 
                   ownerInfo={ownerInfo} 
                />
              </div>
            )}
            
            {activeTab === 'tools' && (
              <div className="animate-in fade-in slide-in-from-bottom-2 duration-300">
                <div className="mb-8">
                  <h3 className="text-2xl font-black mb-2 flex items-center gap-2">Smart Tools <Zap size={20} className="text-amber-400" /></h3>
                  <p className="text-gray-400 text-sm">Utilities to bridge the gap between offline municipalities and your digital business.</p>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* The Offline Form Filler Card */}
                  <div 
                    onClick={() => handleToolClick('digitizer')}
                    className="glass-panel p-8 rounded-[2rem] border border-white/10 hover:border-cyan-500/50 hover:bg-cyan-500/5 transition-all cursor-pointer group relative overflow-hidden"
                  >
                    <div className="absolute top-[-20%] right-[-20%] w-32 h-32 bg-cyan-500/20 rounded-full blur-[50px] group-hover:bg-cyan-500/30 transition-all"></div>
                    <div className="w-16 h-16 rounded-2xl bg-cyan-500/10 text-cyan-400 flex items-center justify-center mb-6 shadow-lg shadow-cyan-500/10">
                      <ScanLine size={32} />
                    </div>
                    <h4 className="text-xl font-black mb-2 group-hover:text-cyan-400 transition-colors">Offline Form Auto-Fill</h4>
                    <p className="text-gray-400 text-sm mb-6 leading-relaxed">
                      Scan physical municipality forms with your camera. Our AI will read them and tell you exactly what to fill in based on your profile.
                    </p>
                    <div className="flex items-center gap-2 text-xs font-bold text-gray-500 uppercase tracking-widest">
                       <Smartphone size={14} /> Mobile Camera Ready
                    </div>
                  </div>

                  {/* AI Presentation Designer Card */}
                  <div 
                    onClick={() => handleToolClick('presentation')}
                    className="glass-panel p-8 rounded-[2rem] border border-white/10 hover:border-purple-500/50 hover:bg-purple-500/5 transition-all cursor-pointer group relative overflow-hidden"
                  >
                    {!isPaid && (
                       <div className="absolute inset-0 bg-black/60 backdrop-blur-[2px] z-10 flex items-center justify-center">
                         <div className="bg-black border border-white/10 px-4 py-2 rounded-xl flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-white">
                            <Lock size={12} /> Pro Feature
                         </div>
                       </div>
                    )}
                    <div className="absolute top-[-20%] right-[-20%] w-32 h-32 bg-purple-500/20 rounded-full blur-[50px] group-hover:bg-purple-500/30 transition-all"></div>
                    <div className="w-16 h-16 rounded-2xl bg-purple-500/10 text-purple-400 flex items-center justify-center mb-6 shadow-lg shadow-purple-500/10">
                      <Presentation size={32} />
                    </div>
                    <h4 className="text-xl font-black mb-2 group-hover:text-purple-400 transition-colors">AI Pitch Deck Designer</h4>
                    <p className="text-gray-400 text-sm mb-6 leading-relaxed">
                      Transform boring text documents into beautiful, illustrated presentations. Perfect for printed funding proposals.
                    </p>
                    <div className="flex items-center gap-2 text-xs font-bold text-gray-500 uppercase tracking-widest">
                       <Sparkles size={14} className="text-amber-400" /> Generative AI Images
                    </div>
                  </div>

                  {/* Proposal Studio Card */}
                  <div 
                    onClick={() => handleToolClick('proposal')}
                    className="glass-panel p-8 rounded-[2rem] border border-white/10 hover:border-emerald-500/50 hover:bg-emerald-500/5 transition-all cursor-pointer group relative overflow-hidden"
                  >
                    {!isPaid && (
                       <div className="absolute inset-0 bg-black/60 backdrop-blur-[2px] z-10 flex items-center justify-center">
                         <div className="bg-black border border-white/10 px-4 py-2 rounded-xl flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-white">
                            <Lock size={12} /> Pro Feature
                         </div>
                       </div>
                    )}
                    <div className="absolute top-[-20%] right-[-20%] w-32 h-32 bg-emerald-500/20 rounded-full blur-[50px] group-hover:bg-emerald-500/30 transition-all"></div>
                    <div className="w-16 h-16 rounded-2xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center mb-6 shadow-lg shadow-emerald-500/10">
                      <FileText size={32} />
                    </div>
                    <h4 className="text-xl font-black mb-2 group-hover:text-emerald-400 transition-colors">Proposal Studio</h4>
                    <p className="text-gray-400 text-sm mb-6 leading-relaxed">
                      Premium funding proposals in minutes. Pick a template, review the AI outline, edit every line, and download a funder-ready PDF — written to each funder's exact rules.
                    </p>
                    <div className="flex items-center gap-2 text-xs font-bold text-gray-500 uppercase tracking-widest">
                       <ShieldCheck size={14} /> Funder-Ready Templates
                    </div>
                  </div>

                  {/* AI Logo Generator Card */}
                  <div 
                    onClick={() => handleToolClick('logo')}
                    className="glass-panel p-8 rounded-[2rem] border border-white/10 hover:border-pink-500/50 hover:bg-pink-500/5 transition-all cursor-pointer group relative overflow-hidden"
                  >
                    {!isPaid && (
                       <div className="absolute inset-0 bg-black/60 backdrop-blur-[2px] z-10 flex items-center justify-center">
                         <div className="bg-black border border-white/10 px-4 py-2 rounded-xl flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-white">
                            <Lock size={12} /> Pro Feature
                         </div>
                       </div>
                    )}
                    <div className="absolute top-[-20%] right-[-20%] w-32 h-32 bg-pink-500/20 rounded-full blur-[50px] group-hover:bg-pink-500/30 transition-all"></div>
                    <div className="w-16 h-16 rounded-2xl bg-pink-500/10 text-pink-400 flex items-center justify-center mb-6 shadow-lg shadow-pink-500/10">
                      <Wand2 size={32} />
                    </div>
                    <h4 className="text-xl font-black mb-2 group-hover:text-pink-400 transition-colors">AI Logo Generator</h4>
                    <p className="text-gray-400 text-sm mb-6 leading-relaxed">
                      Generate professional, high-quality logos for your business instantly using advanced AI image generation.
                    </p>
                    <div className="flex items-center gap-2 text-xs font-bold text-gray-500 uppercase tracking-widest">
                       <Sparkles size={14} className="text-pink-400" /> Custom Branding
                    </div>
                  </div>

                  {/* Funding intake (admin only) */}
                  {isIntakeAdmin && (
                  <div 
                    onClick={() => handleToolClick('whatsapp')}
                    className="glass-panel p-8 rounded-[2rem] border border-white/10 hover:border-emerald-500/50 hover:bg-emerald-500/5 transition-all cursor-pointer group relative overflow-hidden"
                  >
                    <div className="absolute top-[-20%] right-[-20%] w-32 h-32 bg-emerald-500/20 rounded-full blur-[50px] group-hover:bg-emerald-500/30 transition-all"></div>
                    <div className="w-16 h-16 rounded-2xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center mb-6 shadow-lg shadow-emerald-500/10">
                      <Upload size={32} />
                    </div>
                    <h4 className="text-xl font-black mb-2 group-hover:text-emerald-400 transition-colors">Add a Funding Opportunity</h4>
                    <p className="text-gray-400 text-sm mb-6 leading-relaxed">
                      Upload a poster, PDF or pasted text. AI reads it, you check it, then it goes live in the directory.
                    </p>
                    <div className="flex items-center gap-2 text-xs font-bold text-gray-500 uppercase tracking-widest">
                       <CheckCircle size={14} className="text-emerald-400" /> Reviewed before publishing
                    </div>
                  </div>
                  )}
                </div>

                {/* Funding alert preferences — shown to every signed-in user.
                    Lets them opt into email / push / WhatsApp alerts for new
                    funding matches. Server-side endpoint writes to
                    users/{uid}/alert_prefs/main. */}
                {user && (
                  <div className="mt-8">
                    <AlertPreferences user={user} />
                  </div>
                )}
              </div>
            )}
          </div>
        </div>

        <div className="w-full lg:w-72 xl:w-80 shrink-0 space-y-6 lg:space-y-8 min-w-0">
          {/* Cutoff Radar Widget */}
          {(() => {
            const deadlines = compileUserDeadlines(applications, allOpportunities);
            const criticalDeadlines = deadlines.filter(d => d.urgency === 'critical');
            const nextDeadline = deadlines[0];

            return (
              <div className="glass-panel rounded-3xl p-5 sm:p-6 relative overflow-hidden group w-full min-w-0">
                <div className="absolute top-[-20%] right-[-20%] w-32 h-32 bg-rose-500/10 rounded-full blur-3xl pointer-events-none"></div>
                
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-base font-bold flex items-center gap-2">
                    <Clock size={16} className="text-rose-400" /> Cutoff Radar
                  </h3>
                  {criticalDeadlines.length > 0 ? (
                    <span className="px-2 py-0.5 rounded-full text-[9px] font-black uppercase tracking-wider bg-rose-500/20 text-rose-400 border border-rose-500/40 flex items-center gap-1 animate-pulse">
                      <Zap size={9} className="fill-rose-400" /> {criticalDeadlines.length} Critical
                    </span>
                  ) : (
                    <span className="px-2 py-0.5 rounded-full text-[9px] font-black uppercase tracking-wider bg-white/5 text-gray-400">
                      {deadlines.length} Active
                    </span>
                  )}
                </div>

                {nextDeadline ? (
                  <div className="space-y-3">
                    <div className="p-3.5 rounded-2xl bg-black/40 border border-white/5">
                      <span className="text-[10px] uppercase font-bold text-gray-400 block mb-0.5">Next Cutoff</span>
                      <h4 className="text-xs font-bold text-white truncate mb-1.5">{nextDeadline.title}</h4>
                      <div className="flex items-center justify-between">
                        <span className="text-[11px] font-bold text-purple-400 truncate max-w-[130px]">{nextDeadline.provider}</span>
                        <span className={`text-[10px] font-mono font-black px-2 py-0.5 rounded-md ${
                          nextDeadline.urgency === 'critical' ? 'bg-rose-500/20 text-rose-400' : 'bg-white/10 text-white'
                        }`}>
                          {nextDeadline.days > 0 ? `${nextDeadline.days}d ${nextDeadline.hours}h` : `${nextDeadline.hours}h ${nextDeadline.minutes}m`}
                        </span>
                      </div>
                    </div>

                    <button
                      onClick={() => onBrowseFunding(nextDeadline.opportunityId)}
                      className="w-full py-2 px-3 rounded-xl bg-white/5 hover:bg-white/10 border border-white/5 hover:border-white/10 text-xs font-bold text-gray-300 hover:text-white transition-all flex items-center justify-center gap-1.5"
                    >
                      View Deadline Details <ChevronRight size={14} />
                    </button>
                  </div>
                ) : (
                  <p className="text-xs text-gray-500">No active cutoff windows right now.</p>
                )}
              </div>
            );
          })()}

          <ComplianceTracker items={complianceItems} />
          
          {/* AI Readiness Score Card */}
          <div className="glass-panel rounded-3xl p-5 sm:p-6 relative overflow-hidden group w-full min-w-0">
            <div className="absolute top-[-20%] left-[-20%] w-32 h-32 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none"></div>
            <h3 className="text-lg font-bold flex items-center gap-2 mb-6">
              <Target size={18} className="text-cyan-400" /> Readiness Score
            </h3>
            
            {isLoadingReadiness ? (
              <div className="space-y-4 py-4">
                <div className="h-20 bg-white/5 rounded-2xl animate-pulse"></div>
                <div className="h-4 bg-white/5 rounded w-full animate-pulse"></div>
                <div className="h-4 bg-white/5 rounded w-2/3 animate-pulse"></div>
              </div>
            ) : readiness ? (
              <div className="space-y-6 w-full min-w-0">
                <div className="flex flex-col items-center relative py-2">
                  {/* 3D Black Metal Base */}
                  <div className="relative w-36 h-36 rounded-full bg-gradient-to-br from-[#3a414c] via-[#0a0f16] to-[#000000] shadow-[0_15px_25px_rgba(0,0,0,0.9),inset_0_2px_4px_rgba(255,255,255,0.3),inset_0_-4px_8px_rgba(0,0,0,1)] p-[4px] flex items-center justify-center">
                      
                      {/* Inner lip of the base */}
                      <div className="w-full h-full rounded-full bg-gradient-to-b from-[#000] to-[#111] shadow-[inset_0_4px_15px_rgba(0,0,0,1)] flex items-center justify-center p-[2px]">
                        
                        {/* Clear Glass Dome */}
                        <div className="relative w-full h-full rounded-full overflow-hidden flex items-center justify-center bg-black/40 shadow-[inset_0_4px_15px_rgba(255,255,255,0.4),inset_0_-8px_20px_rgba(0,0,0,0.8)] border border-white/20">
                          
                          {/* 3D Glass Highlights (must sit above liquid) */}
                          <div className="absolute inset-0 rounded-full z-20 pointer-events-none">
                            {/* Top curvature bright reflection */}
                            <div className="absolute top-[2%] left-[15%] w-[70%] h-[40%] bg-gradient-to-b from-white/70 to-transparent rounded-[50%] blur-[1.5px]"></div>
                            {/* Subtle rim light at the bottom */}
                            <div className="absolute bottom-[2%] left-[10%] w-[80%] h-[15%] bg-white/30 rounded-[50%] blur-[3px]"></div>
                          </div>
  
                          {/* Liquid container */}
                          <motion.div 
                            initial={{ y: "100%" }}
                          animate={{ y: `${100 - readiness.score}%` }}
                          transition={{ duration: 2, ease: "easeInOut", bounce: 0 }}
                          className="absolute bottom-0 left-0 right-0 h-full bg-gradient-to-t from-cyan-600 via-blue-500 to-purple-500 opacity-95 shadow-[0_-10px_25px_rgba(168,85,247,0.7)] z-0"
                        >
                          {/* Animated Surface Waves */}
                          <motion.div
                            animate={{ x: ["0%", "-50%"] }}
                            transition={{ repeat: Infinity, duration: 4, ease: "linear" }}
                            className="absolute top-0 left-0 w-[200%] h-5 bg-gradient-to-b from-white/50 to-transparent rounded-[50%] blur-[2px]"
                            style={{ marginTop: "-2px" }}
                          />
                          
                          {/* Soda Bubbles */}
                          {[...Array(12)].map((_, i) => (
                            <motion.div 
                              key={i}
                              animate={{ 
                                y: [60 + Math.random() * 40, -140], 
                                x: [0, (Math.random() - 0.5) * 40],
                                opacity: [0, 0.9, 0] 
                              }} 
                              transition={{ 
                                repeat: Infinity, 
                                duration: 1.5 + Math.random() * 2.5, 
                                delay: Math.random() * 2,
                                ease: "easeIn"
                              }} 
                              className="absolute w-2.5 h-2.5 bg-white/80 rounded-full blur-[0.5px]"
                              style={{
                                left: `${15 + Math.random() * 70}%`,
                                bottom: "-15px",
                                transform: `scale(${0.4 + Math.random() * 1.2})`
                              }}
                            />
                          ))}
                        </motion.div>
                        
                        <span className="relative z-10 text-4xl font-black drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)] text-white">{readiness.score}%</span>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="space-y-3 w-full min-w-0">
                  <p className="text-[10px] font-black text-gray-500 uppercase tracking-widest flex items-center gap-2"><Sparkles size={12} className="text-cyan-400 shrink-0" /> AI Coaching Tips</p>
                  {readiness.tips.map((tip, i) => (
                    <div key={i} className="flex gap-2 items-start text-xs text-gray-400 w-full min-w-0">
                      <div className="w-1 h-1 rounded-full bg-cyan-500 mt-1.5 shrink-0"></div>
                      <p className="flex-1 min-w-0 leading-relaxed">{tip}</p>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <div className="text-center py-6">
                <p className="text-xs text-gray-500 mb-4">Complete your profile to generate your AI score.</p>
                <button onClick={onCompleteProfile} className="text-xs font-bold text-cyan-400 hover:underline">Complete Profile</button>
              </div>
            )}
          </div>

          <div className="glass-panel rounded-3xl p-5 sm:p-6 w-full min-w-0">
            <h3 className="text-lg font-bold flex items-center gap-2 mb-6"><Star size={18} className="text-amber-400 fill-amber-400 shrink-0" /> Achievements</h3>
            <div className="space-y-4 w-full min-w-0">
              {MOCK_ACHIEVEMENTS.map((achievement) => {
                const isCompleted = achievement.completed || 
                                   (achievement.id === 'a3' && applications.length > 0) || 
                                   (achievement.id === 'a2' && docCount >= 5) ||
                                   (achievement.id === 'a4' && applications.some(a => a.status === ApplicationStatus.APPROVED));
                
                return (
                  <div key={achievement.id} className={`p-3.5 sm:p-4 rounded-2xl border transition-all w-full min-w-0 ${isCompleted ? 'bg-amber-500/5 border-amber-500/20 shadow-inner' : 'bg-white/5 border-white/5 opacity-50'}`}>
                    <div className="flex items-center gap-3 min-w-0">
                      <div className={`p-2 rounded-lg shrink-0 ${isCompleted ? 'bg-amber-500/20 text-amber-500' : 'bg-gray-800 text-gray-500'}`}>
                        {achievement.icon === 'trophy' ? <Trophy size={18} /> : 
                         achievement.icon === 'upload' ? <Upload size={18} /> :
                         achievement.icon === 'file-text' ? <FileText size={18} /> : <Star size={18} />}
                      </div>
                      <div className="flex-1 min-w-0">
                        <h4 className="text-sm font-bold truncate">{achievement.title}</h4>
                        <p className="text-[10px] text-gray-500 truncate">{achievement.description}</p>
                      </div>
                      {isCompleted && <CheckCircle size={14} className="text-amber-500 shrink-0 ml-auto" />}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>

      {selectedApplicationForTracker && (
        <ApplicationTracker 
          application={selectedApplicationForTracker} 
          onClose={() => setSelectedApplicationForTracker(null)} 
        />
      )}
    </div>
  );
};

export default Dashboard;
