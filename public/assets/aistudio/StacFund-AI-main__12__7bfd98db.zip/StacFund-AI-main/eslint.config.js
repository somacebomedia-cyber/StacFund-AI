import js from '@eslint/js';
import globals from 'globals';
import reactHooks from 'eslint-plugin-react-hooks';
import react from 'eslint-plugin-react';
import tseslint from 'typescript-eslint';

export default tseslint.config(
  { ignores: ['dist', 'node_modules'] },
  {
    extends: [js.configs.recommended, ...tseslint.configs.recommended],
    files: ['**/*.{ts,tsx}'],
    languageOptions: {
      ecmaVersion: 2020,
      globals: globals.browser,
    },
    plugins: {
      'react-hooks': reactHooks,
      react,
    },
    rules: {
      ...reactHooks.configs.recommended.rules,
      '@typescript-eslint/no-unused-vars': ['warn'],
      '@typescript-eslint/no-explicit-any': ['off'],
      '@typescript-eslint/ban-ts-comment': ['off'],
      'react-hooks/exhaustive-deps': ['off'],
      'react-hooks/rules-of-hooks': ['off'],
      'react-hooks/purity': ['off'],
      'react-hooks/set-state-in-effect': ['off'],
      'react-hooks/immutability': ['off'],
      'react-hooks/static-components': ['off'],
      'prefer-const': ['off'],
      'react/no-unescaped-entities': ['off'],
      'preserve-caught-error': ['off'],
      'no-empty': ['off'],
      'no-constant-condition': ['off'],
    },
  }
);
