import { GoogleGenAI } from '@google/genai';

// Helper for exponential backoff sleep
const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

// Helper to determine if an error is retryable (like 503 or 429)
export function isRetryableError(error: any): boolean {
  if (!error) return false;
  const errMsg = (error.message || String(error)).toLowerCase();
  const statusStr = String(error.status || '').toLowerCase();
  const code = String(error.code || error.statusCode || '');

  // Do not retry if prepaid credits are depleted
  if (errMsg.includes('depleted') || errMsg.includes('prepay') || errMsg.includes('billing')) {
    return false;
  }

  return (
    code.includes('503') ||
    code.includes('504') ||
    code.includes('502') ||
    statusStr.includes('unavailable') ||
    errMsg.includes('503') ||
    errMsg.includes('504') ||
    errMsg.includes('502') ||
    errMsg.includes('high demand') ||
    errMsg.includes('try again later') ||
    errMsg.includes('unavailable') ||
    errMsg.includes('unexpected token') ||
    errMsg.includes('<!doctype') ||
    errMsg.includes('is not valid json') ||
    errMsg.includes('failed to fetch') ||
    errMsg.includes('networkerror')
  );
}

// Helper to inspect errors and dispatch a global quota error event for the BYOK banner
function checkAndReportQuotaError(error: any) {
  if (!error) return;
  const msg = (error.message || String(error)).toLowerCase();
  if (
    msg.includes('429') ||
    msg.includes('resource_exhausted') ||
    msg.includes('prepayment') ||
    msg.includes('depleted') ||
    msg.includes('quota') ||
    msg.includes('api key not valid') ||
    msg.includes('api_key_invalid') ||
    msg.includes('invalid_argument')
  ) {
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('gemini_quota_error', {
        detail: { message: error.message || String(error) }
      }));
    }
  }
}

// Helper to normalize any deprecated model names to modern supported models
export function normalizeModelName(modelName?: string): string {
  if (!modelName) return 'gemini-3.8-flash';
  const lower = modelName.toLowerCase();
  if (lower.includes('2.5-flash') || lower.includes('2.0-flash') || lower.includes('1.5-flash')) {
    return 'gemini-3.8-flash';
  }
  if (lower.includes('2.5-pro') || lower.includes('2.0-pro') || lower.includes('1.5-pro')) {
    return 'gemini-3.1-pro-preview';
  }
  return modelName;
}

// Helper to check if a model name is a standard flash model that can fall back to lite
export function canFallbackToLite(modelName: string): boolean {
  if (!modelName) return false;
  const lower = modelName.toLowerCase();
  return (lower.includes('3.8-flash') || lower.includes('flash')) && !lower.includes('image') && !lower.includes('lite');
}

const wrappedModels = new WeakMap<any, any>();

Object.defineProperty(GoogleGenAI.prototype, 'models', {
  get() {
    const rawModels = this._rawModels;
    if (!rawModels) return undefined;

    if (!wrappedModels.has(rawModels)) {
      const wrapper = Object.create(rawModels);

      // Wrap generateContent
      if (typeof rawModels.generateContent === 'function') {
        wrapper.generateContent = async function (params: any, ...args: any[]) {
          let lastError: any = null;
          let currentModel = normalizeModelName(params?.model);
          let retryCount = 0;
          const maxRetries = 3;

          while (retryCount <= maxRetries) {
            try {
              const currentParams = {
                ...params,
                model: currentModel,
              };
              const res = await rawModels.generateContent.call(rawModels, currentParams, ...args);
              try {
                if (typeof window !== 'undefined') {
                  const uid = localStorage.getItem('stacfund_user_id');
                  const plan = localStorage.getItem('stacfund_user_plan');
                  const { recordAiQueryUsage } = await import('./tokenQuotaService');
                  recordAiQueryUsage(uid, plan, false);
                }
              } catch (e) {
                console.error('[Gemini Interceptor] Error recording token usage:', e);
              }
              return res;
            } catch (error: any) {
              lastError = error;
              console.warn(`[Gemini Interceptor] generateContent failed (attempt ${retryCount + 1}/${maxRetries + 1}) with error:`, error);
              checkAndReportQuotaError(error);

              if (isRetryableError(error)) {
                if (canFallbackToLite(currentModel)) {
                  console.warn(`[Gemini Interceptor] High demand detected for ${currentModel}. Falling back to gemini-3.1-flash-lite.`);
                  currentModel = 'gemini-3.1-flash-lite';
                }

                retryCount++;
                if (retryCount <= maxRetries) {
                  const delay = Math.pow(2, retryCount) * 500 + Math.random() * 300;
                  await sleep(delay);
                  continue;
                }
              }
              throw error;
            }
          }
          throw lastError;
        };
      }

      // Wrap generateContentStream
      if (typeof rawModels.generateContentStream === 'function') {
        wrapper.generateContentStream = async function (params: any, ...args: any[]) {
          let lastError: any = null;
          let currentModel = normalizeModelName(params?.model);
          let retryCount = 0;
          const maxRetries = 3;

          while (retryCount <= maxRetries) {
            try {
              const currentParams = {
                ...params,
                model: currentModel,
              };
              const resStream = await rawModels.generateContentStream.call(rawModels, currentParams, ...args);
              try {
                if (typeof window !== 'undefined') {
                  const uid = localStorage.getItem('stacfund_user_id');
                  const plan = localStorage.getItem('stacfund_user_plan');
                  const { recordAiQueryUsage } = await import('./tokenQuotaService');
                  recordAiQueryUsage(uid, plan, true);
                }
              } catch (e) {
                console.error('[Gemini Interceptor] Error recording token usage:', e);
              }
              return resStream;
            } catch (error: any) {
              lastError = error;
              console.warn(`[Gemini Interceptor] generateContentStream failed (attempt ${retryCount + 1}/${maxRetries + 1}) with error:`, error);
              checkAndReportQuotaError(error);

              if (isRetryableError(error)) {
                if (canFallbackToLite(currentModel)) {
                  console.warn(`[Gemini Interceptor] High demand detected for ${currentModel}. Falling back stream to gemini-3.1-flash-lite.`);
                  currentModel = 'gemini-3.1-flash-lite';
                }

                retryCount++;
                if (retryCount <= maxRetries) {
                  const delay = Math.pow(2, retryCount) * 500 + Math.random() * 300;
                  await sleep(delay);
                  continue;
                }
              }
              throw error;
            }
          }
          throw lastError;
        };
      }

      // Preserve all other methods (generateImages, list, editImage, generateVideos)
      for (const key of Object.getOwnPropertyNames(rawModels).concat(Object.keys(rawModels))) {
        if (key !== 'generateContent' && key !== 'generateContentStream' && typeof rawModels[key] === 'function') {
          if (!wrapper[key]) {
            wrapper[key] = rawModels[key].bind(rawModels);
          }
        }
      }

      wrappedModels.set(rawModels, wrapper);
    }
    return wrappedModels.get(rawModels);
  },
  set(val) {
    this._rawModels = val;
  }
});

const wrappedChats = new WeakMap<any, any>();

Object.defineProperty(GoogleGenAI.prototype, 'chats', {
  get() {
    const rawChats = this._rawChats;
    if (!rawChats) return undefined;

    if (!wrappedChats.has(rawChats)) {
      const wrapper = Object.create(rawChats);

      if (typeof rawChats.create === 'function') {
        wrapper.create = function (config: any, ...args: any[]) {
          if (config && config.model) {
            config.model = normalizeModelName(config.model);
          }
          const chatInstance = rawChats.create.call(rawChats, config, ...args);
          if (chatInstance && chatInstance.model) {
            chatInstance.model = normalizeModelName(chatInstance.model);
          }

          // Wrap sendMessage on the returned chatInstance
          const originalSendMessage = chatInstance.sendMessage;
          if (typeof originalSendMessage === 'function') {
            chatInstance.sendMessage = async function (params: any, ...args2: any[]) {
              let lastError: any = null;
              let retryCount = 0;
              const maxRetries = 3;

              while (retryCount <= maxRetries) {
                try {
                  return await originalSendMessage.call(chatInstance, params, ...args2);
                } catch (error: any) {
                  lastError = error;
                  console.warn(`[Gemini Interceptor] sendMessage failed (attempt ${retryCount + 1}/${maxRetries + 1}) with error:`, error);
                  checkAndReportQuotaError(error);

                  if (isRetryableError(error)) {
                    if (canFallbackToLite(chatInstance.model)) {
                      console.warn(`[Gemini Interceptor] High demand detected for ${chatInstance.model}. Falling back chat to gemini-3.1-flash-lite.`);
                      chatInstance.model = 'gemini-3.1-flash-lite';
                    }

                    retryCount++;
                    if (retryCount <= maxRetries) {
                      const delay = Math.pow(2, retryCount) * 500 + Math.random() * 300;
                      await sleep(delay);
                      continue;
                    }
                  }
                  throw error;
                }
              }
              throw lastError;
            };
          }

          // Wrap sendMessageStream on the returned chatInstance
          const originalSendMessageStream = chatInstance.sendMessageStream;
          if (typeof originalSendMessageStream === 'function') {
            chatInstance.sendMessageStream = async function (params: any, ...args2: any[]) {
              let lastError: any = null;
              let retryCount = 0;
              const maxRetries = 3;

              while (retryCount <= maxRetries) {
                try {
                  return await originalSendMessageStream.call(chatInstance, params, ...args2);
                } catch (error: any) {
                  lastError = error;
                  console.warn(`[Gemini Interceptor] sendMessageStream failed (attempt ${retryCount + 1}/${maxRetries + 1}) with error:`, error);
                  checkAndReportQuotaError(error);

                  if (isRetryableError(error)) {
                    if (canFallbackToLite(chatInstance.model)) {
                      console.warn(`[Gemini Interceptor] High demand detected for ${chatInstance.model}. Falling back stream chat to gemini-3.1-flash-lite.`);
                      chatInstance.model = 'gemini-3.1-flash-lite';
                    }

                    retryCount++;
                    if (retryCount <= maxRetries) {
                      const delay = Math.pow(2, retryCount) * 500 + Math.random() * 300;
                      await sleep(delay);
                      continue;
                    }
                  }
                  throw error;
                }
              }
              throw lastError;
            };
          }

          return chatInstance;
        };
      }

      // Preserve all other methods
      for (const key of Object.getOwnPropertyNames(rawChats).concat(Object.keys(rawChats))) {
        if (key !== 'create' && typeof rawChats[key] === 'function') {
          if (!wrapper[key]) {
            wrapper[key] = rawChats[key].bind(rawChats);
          }
        }
      }

      wrappedChats.set(rawChats, wrapper);
    }
    return wrappedChats.get(rawChats);
  },
  set(val) {
    this._rawChats = val;
  }
});
